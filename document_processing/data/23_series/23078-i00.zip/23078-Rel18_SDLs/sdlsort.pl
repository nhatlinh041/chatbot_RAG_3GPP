##  File name -> date
##  Usage: dir | perl sdlsort.pl
##
## Set $WINTYPE 
##        "winxpeng" -- windows xp english
##        "win2kjp"  -- windows 2k japanese
##        "winmejp"  -- windows millenium edition japanese
##
$WINTYPE = "win2kjp";

while (<>){
  if ($WINTYPE eq "winxpeng") {
    if(/([0-9\-]+(\ )+[0-9\:]+)(\ )+[0-9\.]+(\ )+(\w+.sp(d|r))/){
      $date{$5} = $1 ;
    }
  }elsif($WINTYPE eq "win2kjp"){
    if(/([0-9\/]+(\ )+[0-9\:]+)(\ )+[0-9\,]+(\ )+(\w+.sp(d|r))/){
      $date{$5} = $1 ;
    }
  }else{
print "ok2\n";
    if(/([0-9\-]+(\ )+[0-9\:]+) (\w+.sp(d|r))/){
      $date{$3} = $1 ;
    }
  }
}

foreach $file (sort keys %date){
  print "$file\t$date{$file}\n" ;
}

